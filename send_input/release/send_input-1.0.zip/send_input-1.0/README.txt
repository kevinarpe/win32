Win32 SendInput by Kevin Connor ARPE (kevinarpe@gmail.com)

Register Windows global keyboard shortcuts to send keys, usually username or password.

GitHub: https://github.com/kevinarpe/win32/send_input

The file 'send_input.exe' is a 64-bit Windows program.

To view help, try:
DOS> send_input.exe /?
DOS> send_input.exe -h
DOS> send_input.exe --help

See file 'sample_config.txt' for a sample configuration file.

